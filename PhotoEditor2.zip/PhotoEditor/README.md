# PhotoEditor
Simple photo editing app that allows the user to add text,draw over the image, add emojis, rotate and crop, and adjust the brightness,
contrast and saturation of the image.
